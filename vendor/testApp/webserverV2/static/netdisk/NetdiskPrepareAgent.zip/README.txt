Netdisk Prepare Agent
=====================

1. Unzip
2. Double-click StartAgent.bat (keep window open)
3. Open http://124.71.69.102:9526/pan-search
4. Select YOUR computer in the dropdown, click One-click Prepare

If Windows blocks the file (Smart App Control / 智能应用控制):
  A. Right-click NetdiskPrepareAgent.exe -> Properties -> check Unblock -> OK
     Then run StartAgent.bat again
  B. Or: Settings -> Privacy & security -> Windows Security
     -> App & browser control -> Smart App Control -> Off
     (needs reboot), then run StartAgent.bat

StartAgent.bat already tries to Unblock-File automatically.
