@echo off
cd /d "%~dp0"
title Netdisk Prepare Agent
echo.
echo  Unblocking files downloaded from Internet...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Force | Unblock-File" >nul 2>&1
echo  Netdisk Prepare Agent
echo  Keep this window open.
echo  Browser: http://124.71.69.102:9526/pan-search
echo.
if not exist "jump_password.txt" (
  echo ERROR: jump_password.txt missing
  pause
  exit /b 1
)
if not exist "NetdiskPrepareAgent.exe" (
  echo ERROR: NetdiskPrepareAgent.exe missing
  pause
  exit /b 1
)
NetdiskPrepareAgent.exe
if errorlevel 1 (
  echo.
  echo FAILED to start. If Windows Smart App Control blocked it:
  echo   1. Right-click NetdiskPrepareAgent.exe - Properties - Unblock - OK
  echo   2. Or Settings - Privacy - Windows Security - App and browser control
  echo      - Smart App Control - Off
  echo   3. Then run StartAgent.bat again
)
echo.
echo Agent exited.
pause
